import Libro
import Metodos
import Reporte
import System.IO
import System.Directory (doesFileExist)
import Data.Char (toUpper)

-- Función principal del programa
main :: IO ()
main = do
    -- Verificar si el archivo de inventario existe
    fileExists <- doesFileExist "inventario.txt"
    if not fileExists
        then do
            putStrLn "Error: El archivo inventario.txt no existe."
            return ()
        else do
            -- Cargar el inventario
            inventario <- cargarInventario
            bucleMenu inventario

-- Función para mostrar el menú y procesar la selección
bucleMenu :: [Libro] -> IO ()
bucleMenu inventario = do
    putStrLn "\n===== SISTEMA DE GESTIÓN DE LIBRERÍA ====="
    putStrLn "1. Cargar inventario desde archivo"
    putStrLn "2. Guardar inventario en archivo"
    putStrLn "3. Agregar un nuevo libro"
    putStrLn "4. Eliminar un libro"
    putStrLn "5. Buscar un libro"
    putStrLn "6. Listar inventario"
    putStrLn "7. Generar reportes"
    putStrLn "8. Actualizar precio de un libro"
    putStrLn "9. Ordenar inventario"
    putStrLn "10. Exportar informe"
    putStrLn "0. Salir"
    putStrLn "==========================================="
    putStr "Seleccione una opción: "
    hFlush stdout
    opcion <- getLine
    
    case opcion of
        "0" -> putStrLn "¡Hasta pronto!"
        
        "1" -> do  -- Cargar inventario
            nuevoInventario <- cargarInventario
            putStrLn $ "Inventario cargado. " ++ show (length nuevoInventario) ++ " libros encontrados."
            bucleMenu nuevoInventario
            
        "2" -> do  -- Guardar inventario
            guardarInventario inventario
            putStrLn "Inventario guardado exitosamente."
            bucleMenu inventario
            
        "3" -> do  -- Agregar libro
            nuevoLibro <- leerNuevoLibro
            nuevoInventario <- agregarLibro inventario nuevoLibro
            putStrLn "Libro agregado exitosamente."
            bucleMenu nuevoInventario
            
        "4" -> do  -- Eliminar libro
            putStr "Título del libro a eliminar: "
            hFlush stdout
            tit <- getLine
            putStr "Autor del libro a eliminar: "
            hFlush stdout
            aut <- getLine
            nuevoInventario <- eliminarLibro inventario tit aut
            if length nuevoInventario < length inventario
                then putStrLn "Libro eliminado exitosamente."
                else putStrLn "No se encontró el libro especificado."
            bucleMenu nuevoInventario
            
        "5" -> do  -- Buscar libro
            putStrLn "\n----- BUSCAR LIBRO -----"
            putStrLn "1. Buscar por título"
            putStrLn "2. Buscar por autor"
            putStrLn "3. Búsqueda general"
            putStr "Seleccione una opción: "
            hFlush stdout
            opcionBusqueda <- getLine
            
            case opcionBusqueda of
                "1" -> do
                    putStr "Ingrese título a buscar: "
                    hFlush stdout
                    termino <- getLine
                    let resultados = buscarPorTitulo inventario termino
                    mostrarResultadosBusqueda resultados
                "2" -> do
                    putStr "Ingrese autor a buscar: "
                    hFlush stdout
                    termino <- getLine
                    let resultados = buscarPorAutor inventario termino
                    mostrarResultadosBusqueda resultados
                "3" -> do
                    putStr "Ingrese término de búsqueda: "
                    hFlush stdout
                    termino <- getLine
                    let resultados = buscarLibro inventario termino
                    mostrarResultadosBusqueda resultados
                _ -> putStrLn "Opción inválida."
            
            bucleMenu inventario
            
        "6" -> do  -- Listar inventario
            putStrLn "\n===== INVENTARIO DE LIBROS ====="
            putStrLn $ listarInventario inventario
            bucleMenu inventario
            
        "7" -> do  -- Generar reportes
            putStrLn "\n----- REPORTES -----"
            putStrLn "1. Libros con menos de 5 unidades en stock"
            putStrLn "2. Libro más caro y más barato"
            putStrLn "3. Promedio de precios"
            putStrLn "4. Todos los reportes"
            putStr "Seleccione una opción: "
            hFlush stdout
            opcionReporte <- getLine
            
            case opcionReporte of
                "1" -> do
                    let librosBajoStock = librosMenor5Stock inventario
                    putStrLn "\n===== LIBROS CON MENOS DE 5 UNIDADES ====="
                    mapM_ (putStrLn . libroToString) librosBajoStock
                "2" -> do
                    let masCaro = libroMasCaro inventario
                    let masBarato = libroMasBarato inventario
                    putStrLn "\n===== LIBRO MÁS CARO ====="
                    putStrLn $ libroToString masCaro
                    putStrLn "\n===== LIBRO MÁS BARATO ====="
                    putStrLn $ libroToString masBarato
                "3" -> do
                    let promedio = promedioPrecios inventario
                    putStrLn $ "\nPrecio promedio de los libros: $" ++ show promedio
                "4" -> do
                    let librosBajoStock = librosMenor5Stock inventario
                    let masCaro = libroMasCaro inventario
                    let masBarato = libroMasBarato inventario
                    let promedio = promedioPrecios inventario
                    
                    putStrLn "\n===== LIBROS CON MENOS DE 5 UNIDADES ====="
                    mapM_ (putStrLn . libroToString) librosBajoStock
                    
                    putStrLn "\n===== LIBRO MÁS CARO ====="
                    putStrLn $ libroToString masCaro
                    
                    putStrLn "\n===== LIBRO MÁS BARATO ====="
                    putStrLn $ libroToString masBarato
                    
                    putStrLn $ "\nPrecio promedio de los libros: $" ++ show promedio
                _ -> putStrLn "Opción inválida."
            
            bucleMenu inventario
            
        "8" -> do  -- Actualizar precio
            putStr "Título del libro a actualizar: "
            hFlush stdout
            tit <- getLine
            putStr "Autor del libro a actualizar: "
            hFlush stdout
            aut <- getLine
            putStr "Nuevo precio: "
            hFlush stdout
            nuevoPrecio <- readLn
            nuevoInventario <- actualizarPrecioLibro inventario tit aut nuevoPrecio
            putStrLn "Precio actualizado exitosamente."
            bucleMenu nuevoInventario
            
        "9" -> do  -- Ordenar inventario
            putStrLn "\n----- ORDENAR INVENTARIO -----"
            putStrLn "1. Ordenar por título"
            putStrLn "2. Ordenar por autor"
            putStrLn "3. Ordenar por precio"
            putStr "Seleccione una opción: "
            hFlush stdout
            opcionOrdenamiento <- getLine
            
            let criterio = case opcionOrdenamiento of
                    "1" -> "titulo"
                    "2" -> "autor"
                    "3" -> "precio"
                    _ -> ""
            
            if criterio /= "" then do
                let inventarioOrdenado = ordenarInventario inventario criterio
                putStrLn "\n===== INVENTARIO ORDENADO ====="
                putStrLn $ listarInventario inventarioOrdenado
                putStr "¿Desea guardar este ordenamiento? (S/N): "
                hFlush stdout
                respuesta <- getLine
                if (not (null respuesta) && toUpper (head respuesta) == 'S') then do
                    guardarInventario inventarioOrdenado
                    putStrLn "Ordenamiento guardado exitosamente."
                    bucleMenu inventarioOrdenado
                else
                    bucleMenu inventario
            else do
                putStrLn "Opción inválida."
                bucleMenu inventario
            
        "10" -> do  -- Exportar informe
            exportarInforme inventario
            bucleMenu inventario
            
        _ -> do
            putStrLn "Opción inválida. Por favor intente de nuevo."
            bucleMenu inventario

-- Función para leer un nuevo libro desde la entrada del usuario
leerNuevoLibro :: IO Libro
leerNuevoLibro = do
    putStrLn "\n----- AGREGAR NUEVO LIBRO -----"
    putStr "Título: "
    hFlush stdout
    tit <- getLine
    putStr "Autor: "
    hFlush stdout
    aut <- getLine
    putStr "Año de publicación: "
    hFlush stdout
    anio <- readLn
    putStr "Precio: "
    hFlush stdout
    pre <- readLn
    putStr "Cantidad en stock: "
    hFlush stdout
    inv <- readLn
    return $ Libro tit aut anio pre inv

-- Función para mostrar resultados de búsqueda
mostrarResultadosBusqueda :: [Libro] -> IO ()
mostrarResultadosBusqueda [] = putStrLn "No se encontraron libros que coincidan con la búsqueda."
mostrarResultadosBusqueda libros = do
    putStrLn $ "Se encontraron " ++ show (length libros) ++ " libros:"
    putStrLn $ listarInventario libros