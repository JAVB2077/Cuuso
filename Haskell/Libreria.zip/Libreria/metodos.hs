module Metodos (cargarInventario,guardarInvertario,agrgegarLibro,eliminarLibro,buscarLibro,eliminarLibro,buscarLibro,listaInventario,actulizarPrecioLibro,ordenarInventario,exportarInforme) where
import Libro
import Reporte
import System.IO
import System.Directory (removeFile, renameFile)
import Data.List (sortBy, delete)
import Data.Char (toLower)

-- Función para cargar el inventario desde archivo
cargarInventario :: IO [Libro]
cargarInventario = do
    handle <- openFile "inventario.txt" ReadMode
    contents <- hGetContents handle
    let libros = map parseLineToLibro (lines contents)
    hClose handle
    return libros
  where
    parseLineToLibro :: String -> Libro
    parseLineToLibro line = 
        let campos = splitBy ',' line
        in  case campos of
                [t, a, anioStr, precioStr, invStr] -> 
                    Libro t a (read anioStr) (read precioStr) (read invStr)
                _ -> error "Formato de línea inválido en el archivo de inventario"

-- Función auxiliar para dividir una cadena por un delimitador
splitBy :: Char -> String -> [String]
splitBy delimiter = foldr (\c acc -> if c == delimiter 
                                    then "":acc 
                                    else (c:head acc):tail acc) [""]

-- Función para guardar el inventario en archivo
guardarInventario :: [Libro] -> IO ()
guardarInventario libros = do
    (tempName, tempHandle) <- openTempFile "." "temp"
    hPutStr tempHandle $ unlines $ map libroToLine libros
    hClose tempHandle
    removeFile "inventario.txt"
    renameFile tempName "inventario.txt"
  where
    libroToLine :: Libro -> String
    libroToLine (Libro t a anio p inv) = 
        t ++ "," ++ a ++ "," ++ show anio ++ "," ++ show p ++ "," ++ show inv

-- Función para agregar un nuevo libro
agregarLibro :: [Libro] -> Libro -> IO [Libro]
agregarLibro libros nuevoLibro = do
    let libroExistente = filter (\l -> titulo l == titulo nuevoLibro && 
                                     autor l == autor nuevoLibro) libros
    let nuevaLista = case libroExistente of
            [libro] -> map (\l -> if titulo l == titulo nuevoLibro && 
                                   autor l == autor nuevoLibro
                                then l { inventario = inventario l + inventario nuevoLibro }
                                else l) libros
            [] -> nuevoLibro : libros
    guardarInventario nuevaLista
    return nuevaLista

-- Función para eliminar un libro
eliminarLibro :: [Libro] -> String -> String -> IO [Libro]
eliminarLibro libros tituloLibro autorLibro = do
    let libroAEliminar = filter (\l -> titulo l == tituloLibro && 
                                     autor l == autorLibro) libros
    case libroAEliminar of
        [libro] -> do
            let nuevaLista = delete libro libros
            guardarInventario nuevaLista
            return nuevaLista
        _ -> return libros

-- Función para buscar un libro por título o autor
buscarLibro :: [Libro] -> String -> [Libro]
buscarLibro libros consulta =
    filter (\l -> contiene (map toLower $ titulo l) consultaLower || 
                  contiene (map toLower $ autor l) consultaLower) libros
  where
    consultaLower = map toLower consulta
    contiene str substr = substr `isInfixOf` str

-- Función auxiliar para verificar si una subcadena está contenida en otra
isInfixOf :: Eq a => [a] -> [a] -> Bool
isInfixOf [] _ = True
isInfixOf _ [] = False
isInfixOf pat str@(_:strTail) =
    isPrefixOf pat str || isInfixOf pat strTail

-- Función auxiliar para verificar si una cadena es prefijo de otra
isPrefixOf :: Eq a => [a] -> [a] -> Bool
isPrefixOf [] _ = True
isPrefixOf _ [] = False
isPrefixOf (p:ps) (s:ss) = p == s && isPrefixOf ps ss

-- Función para buscar un libro por título específicamente
buscarPorTitulo :: [Libro] -> String -> [Libro]
buscarPorTitulo libros tituloConsulta =
    filter (\l -> contiene (map toLower $ titulo l) consultaLower) libros
  where
    consultaLower = map toLower tituloConsulta
    contiene str substr = substr `isInfixOf` str

-- Función para buscar un libro por autor específicamente
buscarPorAutor :: [Libro] -> String -> [Libro]
buscarPorAutor libros autorConsulta =
    filter (\l -> contiene (map toLower $ autor l) consultaLower) libros
  where
    consultaLower = map toLower autorConsulta
    contiene str substr = substr `isInfixOf` str

-- Función para listar el inventario
listarInventario :: [Libro] -> String
listarInventario libros = 
    unlines $ zipWith (\n l -> show n ++ " - " ++ libroToString l) [0..] libros

-- Función para convertir un libro a cadena de texto formateada
libroToString :: Libro -> String
libroToString (Libro t a anio p inv) = 
    t ++ " por " ++ a ++ " (" ++ show anio ++ ") - $" ++ show p ++ " - " ++ show inv ++ " unidades"

-- Función para actualizar el precio de un libro
actualizarPrecioLibro :: [Libro] -> String -> String -> Float -> IO [Libro]
actualizarPrecioLibro libros tituloLibro autorLibro nuevoPrecio = do
    let nuevaLista = map updatePrecio libros
    guardarInventario nuevaLista
    return nuevaLista
  where
    updatePrecio libro
        | titulo libro == tituloLibro && autor libro == autorLibro = 
            libro { precio = nuevoPrecio }
        | otherwise = libro

-- Función para ordenar el inventario de diferentes maneras
ordenarInventario :: [Libro] -> String -> [Libro]
ordenarInventario libros criterio =
    case criterio of
        "titulo" -> sortBy (\a b -> compare (titulo a) (titulo b)) libros
        "autor" -> sortBy (\a b -> compare (autor a) (autor b)) libros
        "precio" -> sortBy (\a b -> compare (precio a) (precio b)) libros
        _ -> libros  -- Si no se especifica un criterio válido, devolver sin ordenar

-- Función para exportar un informe completo
exportarInforme :: [Libro] -> IO ()
exportarInforme libros = do
    let inventarioStr = "===== INVENTARIO DE LIBROS =====\n\n" ++ listarInventario libros
    let librosBajoStockStr = "===== LIBROS CON MENOS DE 5 UNIDADES =====\n\n" ++ 
                             unlines (map libroToString (librosMenor5Stock libros))
    let libroMasCaroStr = "===== LIBRO MÁS CARO =====\n\n" ++ 
                          libroToString (libroMasCaro libros)
    let libroMasBaratoStr = "===== LIBRO MÁS BARATO =====\n\n" ++ 
                            libroToString (libroMasBarato libros)
    let promedioPreciosStr = "===== PROMEDIO DE PRECIOS =====\n\n" ++ 
                             "Precio promedio: $" ++ show (promedioPrecios libros) ++ "\n"
    
    -- Exportar el informe
    writeFile "reporte.txt" $ unlines [
        inventarioStr,
        librosBajoStockStr,
        libroMasCaroStr,
        libroMasBaratoStr,
        promedioPreciosStr
        ]
    putStrLn "Informe exportado a reporte.txt"