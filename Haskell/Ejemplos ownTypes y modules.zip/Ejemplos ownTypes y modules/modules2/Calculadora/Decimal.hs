module Calculadora.Decimal(
    sumar,
    restar
 ) where

sumar :: Double -> Double -> Double
sumar n m = n + m 

restar :: Double -> Double -> Double
restar n m = n - m