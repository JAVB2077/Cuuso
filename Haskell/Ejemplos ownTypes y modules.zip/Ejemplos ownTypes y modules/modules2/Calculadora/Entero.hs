module Calculadora.Entero(
    sumar,
    restar
 ) where

sumar :: Integer -> Integer -> Integer
sumar n m = n + m 

restar :: Integer -> Integer -> Integer
restar n m = n - m