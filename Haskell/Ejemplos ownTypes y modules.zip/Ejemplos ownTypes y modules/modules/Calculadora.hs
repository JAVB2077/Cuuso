module Calculadora(
    sumar,
    restar,
    multiplicar,
    dividir
 ) where

sumar :: Integer -> Integer -> Integer
sumar n m = n + m 

restar :: Integer -> Integer -> Integer
restar n m = n - m 

multiplicar :: Integer -> Integer -> Integer
multiplicar n m = n * m 

dividir :: Double -> Double -> Double
dividir n m = n / m 